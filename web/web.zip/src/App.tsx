import { BrowserRouter, Routes, Route } from "react-router";
import { Toaster } from "sonner";
import { AuthProvider } from "./auth/AuthProvider";
import { SocketProvider } from "./socket/SocketProvider";
import { NotificationsProvider } from "./notifications/NotificationsProvider";
import { MatchFoundProvider } from "./matchmaking/MatchFoundProvider";
import { LobbyProvider } from "./hooks/useLobby";
import { Navbar } from "./components/Navbar";
import { ScrollToTop } from "./components/ScrollToTop";
import { LandingView } from "./views/LandingView";
import { FrontPageView } from "./views/FrontPageView";
import { LoginView } from "./views/LoginView";
import { AboutView } from "./views/AboutView";
import { CreditsView } from "./views/CreditsView";
import { HostView } from "./views/HostView";
import { ServersView } from "./views/ServersView";
import { ServerApplyView } from "./views/ServerApplyView";
import { ServerDetailsView } from "./views/ServerDetailsView";
import { ProfileView } from "./views/ProfileView";
import { SettingsView } from "./views/SettingsView";
import { PrivacyPolicyView } from "./views/PrivacyPolicyView";
import { NotFoundView } from "./views/NotFoundView";

export function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SocketProvider>
          <NotificationsProvider>
            <MatchFoundProvider>
              <LobbyProvider>
                <ScrollToTop />
                <Navbar />

                <main className="mx-auto flex min-h-[calc(100vh-4rem)] w-full max-w-7xl flex-col px-4 py-6 md:px-6">
                  <Routes>
                    <Route path="/" element={<FrontPageView />} />
                    <Route path="/landing" element={<LandingView />} />
                    <Route path="/login" element={<LoginView />} />
                    <Route path="/about" element={<AboutView />} />
                    <Route path="/credits" element={<CreditsView />} />
                    <Route path="/host" element={<HostView />} />
                    <Route path="/servers" element={<ServersView />} />
                    <Route
                      path="/servers/apply"
                      element={<ServerApplyView />}
                    />
                    <Route
                      path="/servers/:serverId"
                      element={<ServerDetailsView />}
                    />
                    <Route path="/profile/:steamId" element={<ProfileView />} />
                    <Route path="/settings" element={<SettingsView />} />
                    <Route path="/privacy" element={<PrivacyPolicyView />} />
                    <Route path="*" element={<NotFoundView />} />
                  </Routes>
                </main>

                <Toaster
                  richColors
                  closeButton
                  toastOptions={{
                    className: "app-toast",
                  }}
                />
              </LobbyProvider>
            </MatchFoundProvider>
          </NotificationsProvider>
        </SocketProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
