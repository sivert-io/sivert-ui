import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { useSocket } from "../socket/useSocket";
import { useAuth } from "../auth/useAuth";
import { API_BASE_URL } from "../lib/api";
import { NotificationsContext } from "./NotificationsContext";
import type { Notification } from "./types";
import { usePushNotifications } from "../push";

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { socket, isConnected } = useSocket();
  const { isSignedIn, isLoading } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { showLocalPushNotification } = usePushNotifications();

  const inviteAudioRef = useRef<HTMLAudioElement | null>(null);
  const inviteAudioReadyRef = useRef(false);

  useEffect(() => {
    const audio = new Audio("/sounds/invite-received.mp3");
    audio.preload = "auto";
    audio.volume = 0.5;

    const handleCanPlayThrough = () => {
      inviteAudioReadyRef.current = true;
    };

    const handleError = (event: Event) => {
      inviteAudioReadyRef.current = false;
      console.error("Invite sound failed to load:", event);
    };

    inviteAudioRef.current = audio;
    inviteAudioReadyRef.current = false;

    audio.addEventListener("canplaythrough", handleCanPlayThrough);
    audio.addEventListener("error", handleError);

    audio.load();

    return () => {
      audio.pause();
      audio.removeEventListener("canplaythrough", handleCanPlayThrough);
      audio.removeEventListener("error", handleError);
      inviteAudioRef.current = null;
      inviteAudioReadyRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (isLoading) return;

    if (!isSignedIn) {
      setNotifications([]);
      return;
    }

    let cancelled = false;

    async function loadNotifications() {
      try {
        const response = await fetch(`${API_BASE_URL}/notifications`, {
          credentials: "include",
        });

        if (!response.ok) {
          throw new Error("Failed to load notifications");
        }

        const data = await response.json();

        if (!cancelled) {
          setNotifications(data.notifications ?? []);
        }
      } catch (error) {
        console.error(error);
      }
    }

    void loadNotifications();

    return () => {
      cancelled = true;
    };
  }, [isSignedIn, isLoading]);

  useEffect(() => {
    function onNotification(payload: Notification) {
      setNotifications((prev) => {
        const exists = prev.some((item) => item.id && item.id === payload.id);
        if (exists) return prev;
        return [payload, ...prev];
      });

      if (payload.type === "lobby_invite") {
        const audio = inviteAudioRef.current;
        const isReady = inviteAudioReadyRef.current;

        if (audio && isReady) {
          audio.pause();
          audio.currentTime = 0;

          void audio.play().catch((error) => {
            console.error("Failed to play invite sound:", error);
          });
        } else {
          console.warn("Invite sound not ready yet");
        }
      }

      if (
        payload.type === "lobby_invite" &&
        document.visibilityState !== "visible"
      ) {
        void showLocalPushNotification({
          title: payload.title,
          body: payload.body,
          url: "/",
          tag: `flow-lobby-invite-${payload.id}`,
          kind: "lobby_invite",
        });
      }

      toast(payload.title, {
        description: payload.body,
      });
    }

    function onNotificationDeleted(payload: { id?: string }) {
      if (!payload.id) return;
      setNotifications((prev) => prev.filter((item) => item.id !== payload.id));
    }

    socket.on("notification:new", onNotification);
    socket.on("notification:deleted", onNotificationDeleted);

    return () => {
      socket.off("notification:new", onNotification);
      socket.off("notification:deleted", onNotificationDeleted);
    };
  }, [socket, showLocalPushNotification]);

  async function deleteNotification(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/notifications/${id}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (!response.ok && response.status !== 404) {
        throw new Error("Failed to delete notification");
      }

      setNotifications((prev) => prev.filter((item) => item.id !== id));
    } catch (error) {
      console.error(error);
    }
  }

  async function markAsRead(id: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/notifications/${id}/read`, {
        method: "POST",
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Failed to mark notification as read");
      }

      setNotifications((prev) =>
        prev.map((item) =>
          item.id === id
            ? {
                ...item,
                readAt: new Date().toISOString(),
              }
            : item,
        ),
      );
    } catch (error) {
      console.error(error);
    }
  }

  async function clearNotifications() {
    try {
      const response = await fetch(`${API_BASE_URL}/notifications`, {
        method: "DELETE",
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Failed to clear notifications");
      }

      setNotifications([]);
    } catch (error) {
      console.error(error);
    }
  }

  const value = useMemo(
    () => ({
      notifications,
      isConnected,
      clearNotifications,
      deleteNotification,
      markAsRead,
    }),
    [notifications, isConnected],
  );

  return (
    <NotificationsContext.Provider value={value}>
      {children}
    </NotificationsContext.Provider>
  );
}
