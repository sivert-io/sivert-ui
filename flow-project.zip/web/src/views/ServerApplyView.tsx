import { Card } from "../components/Card";
import { InputField } from "../components/InputField/InputField";
import { Button } from "../components/Button";
import { Accordion } from "../components/Accordion";
import { useMemo, useState } from "react";

const fakeToken = "flow_verify_8f2e3a19b1";
const detectedCountry = "Norway";
const detectedRegion = "EU North";

function StepPill({
  active,
  complete,
  label,
  index,
}: {
  active?: boolean;
  complete?: boolean;
  label: string;
  index: number;
}) {
  return (
    <div
      className={[
        "flex items-center gap-3 rounded-2xl border px-4 py-3",
        active
          ? "border-primary/30 bg-primary/10"
          : complete
            ? "border-success/20 bg-success/10"
            : "border-primary/15 bg-black/10",
      ].join(" ")}
    >
      <div
        className={[
          "grid h-7 w-7 place-items-center rounded-full text-xs font-bold",
          active
            ? "bg-primary text-background"
            : complete
              ? "bg-success text-background"
              : "bg-white/10 text-primary",
        ].join(" ")}
      >
        {index}
      </div>
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}

export function ServerApplyView() {
  const [step, setStep] = useState(1);
  const [ip, setIp] = useState("");
  const [port, setPort] = useState("27015");
  const [serverName, setServerName] = useState("");
  const [contact, setContact] = useState("");

  const canGoToReview = useMemo(() => {
    return ip.trim() && port.trim() && serverName.trim() && contact.trim();
  }, [ip, port, serverName, contact]);

  return (
    <div className="grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
      <div className="flex flex-col gap-3">
        <StepPill
          index={1}
          label="Eligibility"
          active={step === 1}
          complete={step > 1}
        />
        <StepPill
          index={2}
          label="Server details"
          active={step === 2}
          complete={step > 2}
        />
        <StepPill
          index={3}
          label="Verification"
          active={step === 3}
          complete={step > 3}
        />
        <StepPill index={4} label="Review" active={step === 4} />
      </div>

      <Card>
        <div className="flex flex-col gap-6">
          {step === 1 ? (
            <>
              <div className="flex flex-col gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                  Step 1
                </p>
                <h1 className="text-2xl font-bold">Host eligibility</h1>
                <p className="text-sm text-foreground-muted">
                  Hosting is meant to be lightweight to join, but approved
                  servers still need to meet basic trust and operational
                  requirements.
                </p>
              </div>

              <div className="grid gap-3 text-sm">
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  Your server should have stable uptime and predictable
                  connectivity.
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  You must install the FLOW plugin to verify ownership and
                  exchange server health data.
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  Hosts are expected to follow platform rules and avoid
                  tampering, griefing, or manipulation.
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={() => setStep(2)}>Continue</Button>
              </div>
            </>
          ) : null}

          {step === 2 ? (
            <>
              <div className="flex flex-col gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                  Step 2
                </p>
                <h1 className="text-2xl font-bold">Server details</h1>
                <p className="text-sm text-foreground-muted">
                  Start with the basics. FLOW can infer some metadata from the
                  server IP after submission.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <InputField
                  label="Server IP *"
                  placeholder="123.123.123.123"
                  value={ip}
                  onChange={(e) => setIp(e.target.value)}
                />
                <InputField
                  label="Port *"
                  placeholder="27015"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                />
                <InputField
                  label="Server display name *"
                  placeholder="FLOW Oslo #1"
                  value={serverName}
                  onChange={(e) => setServerName(e.target.value)}
                />
                <InputField
                  label="Contact method *"
                  placeholder="Discord, email, or Steam"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                />
              </div>

              <div className="grid gap-3 rounded-2xl border border-primary/15 bg-black/10 p-4 md:grid-cols-2">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Detected country
                  </p>
                  <p className="mt-1 text-sm">{detectedCountry}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Routing region
                  </p>
                  <p className="mt-1 text-sm">{detectedRegion}</p>
                </div>
              </div>

              <div className="flex justify-between gap-3">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button onClick={() => setStep(3)} disabled={!canGoToReview}>
                  Continue
                </Button>
              </div>
            </>
          ) : null}

          {step === 3 ? (
            <>
              <div className="flex flex-col gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                  Step 3
                </p>
                <h1 className="text-2xl font-bold">Verify ownership</h1>
                <p className="text-sm text-foreground-muted">
                  Install the FLOW plugin on your server and add the token below
                  to the plugin configuration.
                </p>
              </div>

              <div className="rounded-2xl border border-secondary/20 bg-secondary/10 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-secondary/80">
                  Verification token
                </p>
                <p className="mt-2 break-all font-mono text-sm">{fakeToken}</p>
              </div>

              <div className="grid gap-3">
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4 text-sm">
                  1. Install the FLOW server plugin
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4 text-sm">
                  2. Add the token to your plugin config
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4 text-sm">
                  3. Restart or reload your server
                </div>
                <div className="rounded-2xl border border-success/20 bg-success/10 p-4 text-sm text-success">
                  4. Verification check passed
                </div>
              </div>

              <Accordion label="Why do I need to verify ownership?">
                <p className="text-sm text-foreground-muted">
                  Verification prevents users from registering servers they do
                  not control and lets FLOW confirm that your plugin is working
                  correctly.
                </p>
              </Accordion>

              <div className="flex justify-between gap-3">
                <Button variant="ghost" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button onClick={() => setStep(4)}>Continue</Button>
              </div>
            </>
          ) : null}

          {step === 4 ? (
            <>
              <div className="flex flex-col gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                  Step 4
                </p>
                <h1 className="text-2xl font-bold">Review submission</h1>
                <p className="text-sm text-foreground-muted">
                  Confirm the details below before you submit your host
                  application.
                </p>
              </div>

              <div className="grid gap-3">
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Server
                  </p>
                  <p className="mt-1 text-sm">{serverName}</p>
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Address
                  </p>
                  <p className="mt-1 text-sm">
                    {ip}:{port}
                  </p>
                </div>
                <div className="rounded-2xl border border-primary/15 bg-black/10 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Region
                  </p>
                  <p className="mt-1 text-sm">
                    {detectedCountry} · {detectedRegion}
                  </p>
                </div>
                <div className="rounded-2xl border border-success/20 bg-success/10 p-4">
                  <p className="text-sm font-medium text-success">
                    Ownership verification passed
                  </p>
                </div>
              </div>

              <div className="flex justify-between gap-3">
                <Button variant="ghost" onClick={() => setStep(3)}>
                  Back
                </Button>
                <Button href="/servers" variant="solid">
                  Submit application
                </Button>
              </div>
            </>
          ) : null}
        </div>
      </Card>
    </div>
  );
}
