import { Card } from "../components/Card";
import { Button } from "../components/Button";
import { useParams } from "react-router";

function StatusChip({
  children,
  tone = "success",
}: {
  children: React.ReactNode;
  tone?: "success" | "warning" | "danger";
}) {
  const classes =
    tone === "success"
      ? "border-success/20 bg-success/10 text-success"
      : tone === "warning"
        ? "border-secondary/20 bg-secondary/10 text-secondary"
        : "border-danger/20 bg-danger/10 text-danger";

  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${classes}`}
    >
      {children}
    </span>
  );
}

export function ServerDetailsView() {
  const { serverId } = useParams();

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Server Overview
            </p>
            <h1 className="text-3xl font-bold">FLOW Oslo #1</h1>
            <p className="text-sm text-foreground-muted">
              Server ID: {serverId}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <StatusChip>Verified</StatusChip>
            <StatusChip tone="warning">In match</StatusChip>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Region
            </p>
            <p className="text-xl font-bold">Norway</p>
            <p className="text-sm text-foreground-muted">EU North</p>
          </div>
        </Card>

        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Last heartbeat
            </p>
            <p className="text-xl font-bold">12s ago</p>
            <p className="text-sm text-foreground-muted">Healthy</p>
          </div>
        </Card>

        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Plugin version
            </p>
            <p className="text-xl font-bold">1.0.2</p>
            <p className="text-sm text-foreground-muted">Up to date</p>
          </div>
        </Card>

        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Availability
            </p>
            <p className="text-xl font-bold">In match</p>
            <p className="text-sm text-foreground-muted">Abstract state only</p>
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex flex-col gap-4">
          <h2 className="text-xl font-bold">Host actions</h2>
          <div className="flex flex-wrap gap-3">
            <Button variant="ghost">Rotate token</Button>
            <Button variant="ghost">Re-run verification</Button>
            <Button variant="ghost">Enable drain mode</Button>
            <Button variant="ghost" color="danger">
              Remove server
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex flex-col gap-4">
          <h2 className="text-xl font-bold">Notes</h2>
          <p className="text-sm text-foreground-muted">
            This page intentionally shows only high-level operational state such
            as verification, plugin health, and availability. It should not
            expose player identities, internal routing logic, or abuse-detection
            signals.
          </p>
        </div>
      </Card>
    </div>
  );
}
