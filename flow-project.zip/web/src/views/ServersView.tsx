import { Card } from "../components/Card";
import { Button } from "../components/Button";
import { HostBadge } from "../components/HostBadge";
import { useAuth } from "../auth/useAuth";

type DemoServer = {
  id: string;
  name: string;
  region: string;
  status: "Verified" | "Pending review" | "Needs attention";
  pluginVersion: string;
  lastHeartbeat: string;
};

const demoServers: DemoServer[] = [
  {
    id: "oslo-1",
    name: "FLOW Oslo #1",
    region: "Norway",
    status: "Verified",
    pluginVersion: "1.0.2",
    lastHeartbeat: "12s ago",
  },
  {
    id: "stokholm-2",
    name: "FLOW Stockholm #2",
    region: "Sweden",
    status: "Pending review",
    pluginVersion: "1.0.2",
    lastHeartbeat: "2m ago",
  },
];

function StatusChip({
  status,
}: {
  status: DemoServer["status"] | "Online" | "Offline" | "In match";
}) {
  const classes =
    status === "Verified" || status === "Online"
      ? "border-success/20 bg-success/10 text-success"
      : status === "Pending review" || status === "In match"
        ? "border-secondary/20 bg-secondary/10 text-secondary"
        : "border-danger/20 bg-danger/10 text-danger";

  return (
    <span
      className={`inline-flex w-fit rounded-full border px-2.5 py-1 text-xs font-medium ${classes}`}
    >
      {status}
    </span>
  );
}

function EmptyState() {
  return (
    <Card>
      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="flex flex-col gap-4">
          <div className="inline-flex w-fit rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
            Community Servers
          </div>
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold">Become a host</h1>
            <p className="max-w-2xl text-sm text-foreground-muted">
              Register and verify your CS2 server to help power the FLOW
              community. Approved hosts receive a public badge and access to
              server management tools.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button href="/servers/apply" variant="solid">
              Apply to host
            </Button>
            <Button href="/host" variant="ghost">
              How hosting works
            </Button>
          </div>
        </div>

        <div className="rounded-3xl border border-primary/15 bg-black/10 p-5">
          <div className="flex flex-col gap-4">
            <h2 className="text-lg font-semibold">Why host?</h2>
            <div className="flex flex-col gap-3 text-sm text-foreground-muted">
              <p>Support fair, community-first CS2 matchmaking.</p>
              <p>Keep control of your own hardware and setup.</p>
              <div className="flex items-center gap-2">
                <span>Earn the</span>
                <HostBadge />
                <span>badge.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function HostDashboard() {
  return (
    <div className="flex flex-col gap-6">
      <Card>
        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-3xl font-bold">Your servers</h1>
              <HostBadge />
            </div>
            <p className="text-sm text-foreground-muted">
              Manage registered servers, verify plugin health, and review
              actions that need your attention.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button href="/servers/apply" variant="solid">
              Add server
            </Button>
            <Button href="/host" variant="ghost">
              Host docs
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Registered
            </p>
            <p className="text-3xl font-bold">2</p>
            <p className="text-sm text-foreground-muted">
              Servers on your account
            </p>
          </div>
        </Card>
        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Verified
            </p>
            <p className="text-3xl font-bold">1</p>
            <p className="text-sm text-foreground-muted">
              Ready for production
            </p>
          </div>
        </Card>
        <Card>
          <div className="flex flex-col gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
              Needs attention
            </p>
            <p className="text-3xl font-bold">1</p>
            <p className="text-sm text-foreground-muted">
              Verification or connectivity issue
            </p>
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-xl font-bold">My servers</h2>
            <Button href="/servers/apply" size="sm" variant="ghost">
              Register another
            </Button>
          </div>

          <div className="grid gap-3">
            {demoServers.map((server) => (
              <div
                key={server.id}
                className="grid gap-4 rounded-2xl border border-primary/15 bg-black/10 p-4 lg:grid-cols-[1.4fr_0.8fr_0.8fr_0.7fr_auto]"
              >
                <div className="flex flex-col gap-1">
                  <p className="font-semibold">{server.name}</p>
                  <p className="text-sm text-foreground-muted">
                    {server.region}
                  </p>
                </div>

                <div className="flex flex-col gap-1">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Status
                  </p>
                  <StatusChip status={server.status} />
                </div>

                <div className="flex flex-col gap-1">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Plugin
                  </p>
                  <p className="text-sm">{server.pluginVersion}</p>
                </div>

                <div className="flex flex-col gap-1">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary/70">
                    Last heartbeat
                  </p>
                  <p className="text-sm">{server.lastHeartbeat}</p>
                </div>

                <div className="flex items-center">
                  <Button
                    href={`/servers/${server.id}`}
                    size="sm"
                    variant="ghost"
                  >
                    Manage
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

export function ServersView() {
  const { user } = useAuth();

  const isHost =
    user?.role === "admin" ||
    user?.personaName?.toLowerCase().includes("flow") ||
    true;

  return isHost ? <HostDashboard /> : <EmptyState />;
}
